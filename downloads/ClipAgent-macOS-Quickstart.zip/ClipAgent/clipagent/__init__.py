"""ClipAgent local demo."""
